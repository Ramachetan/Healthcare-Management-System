-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2017 at 11:52 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `bill` (IN `appno` BIGINT(10), OUT `medical_bill` INT(10), OUT `room_rent` INT(10), OUT `doctor_fees` INT(10))  begin
	declare days int(5);
	declare in_date date;
	declare out_date date;
	declare type_ varchar(3);
	
	select pat_type  into type_
	from appointment
	where app_no = appno;
	
	if type_ = 'in' then 
		select date_admitted, date_discharged into in_date,out_date 
		from  appointment natural join patient_admit 
		where app_no = appno;
	
		if out_date=0000-00-00 then
			set days =date(sysdate())-in_date;
			set room_rent=(days+1)*500;
		else
	 		set days = out_date-in_date;
			set room_rent = (days+1)*500;
		end if;
	else 
		set room_rent=0;
	end if;
	
	select consultation into doctor_fees 
	from emp_doctor 
	where doc_id in(select doc_id from appointment where app_no = appno);
	
	select med_price into medical_bill 
	from appointment
	where app_no =appno;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `app_no` bigint(10) UNSIGNED NOT NULL,
  `pat_id` bigint(10) UNSIGNED NOT NULL,
  `doc_id` bigint(10) UNSIGNED NOT NULL,
  `app_date` date NOT NULL,
  `description` varchar(100) NOT NULL DEFAULT 'NOT YET CONSULTED',
  `pat_type` varchar(3) NOT NULL DEFAULT 'out',
  `med_price` int(5) NOT NULL DEFAULT '0',
  `checked` varchar(5) NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`app_no`, `pat_id`, `doc_id`, `app_date`, `description`, `pat_type`, `med_price`, `checked`) VALUES
(26, 72, 4, '2017-06-06', 'NOT YET CONSULTED', 'out', 0, 'false'),
(32, 72, 6, '2017-12-16', 'lokjh', 'in', 1025, 'true'),
(33, 73, 6, '2017-01-01', 'NOT YET CONSULTED', 'out', 500, 'false'),
(34, 74, 6, '2017-12-14', 'NOT YET CONSULTED', 'out', 0, 'false'),
(38, 76, 1, '2017-11-25', 'NOT YET CONSULTED', 'out', 0, 'false'),
(40, 78, 1, '2017-12-15', 'NOT YET CONSULTED', 'out', 0, 'false'),
(41, 79, 10, '2017-12-15', 'NOT YET CONSULTED', 'out', 0, 'false'),
(42, 75, 10, '2017-12-15', 'NOT YET CONSULTED', 'out', 0, 'false'),
(43, 80, 12, '2017-11-11', 'NOT YET CONSULTED', 'out', 0, 'false'),
(44, 81, 13, '2017-11-11', 'general check up', 'out', 0, 'true'),
(45, 81, 13, '2017-11-11', 'NOT YET CONSULTED', 'out', 0, 'false'),
(46, 82, 20, '2017-11-12', 'sfjkj uioefho in8ig ng heroih oighpoefo;IWg fvaghuifeiuqH OG;P', 'in', 450, 'true'),
(47, 83, 13, '2017-07-11', 'HE IS PERFECTLY ALRIGHT', 'in', 5050, 'true'),
(48, 83, 15, '2017-12-15', 'NOT YET CONSULTED', 'out', 0, 'false'),
(49, 83, 13, '2017-12-15', 'NOT YET CONSULTED', 'out', 0, 'false'),
(50, 82, 15, '2017-12-15', 'NOT YET CONSULTED', 'out', 0, 'false'),
(51, 81, 15, '2017-12-15', 'qwerertyyuiu', 'in', 0, 'true'),
(52, 76, 15, '2017-11-11', 'NOT YET CONSULTED', 'out', 0, 'false'),
(53, 78, 15, '2017-11-11', 'NOT YET CONSULTED', 'out', 0, 'false'),
(54, 79, 15, '2017-11-11', 'ydhdh', 'out', 0, 'true'),
(55, 85, 14, '3017-03-01', 'NOT YET CONSULTED', 'out', 0, 'false'),
(56, 86, 15, '2017-11-12', 'NOT YET CONSULTED', 'out', 0, 'false'),
(57, 72, 32, '2017-11-13', 'NOT YET CONSULTED', 'out', 0, 'false'),
(58, 87, 1, '2017-11-13', ' 100% OK', 'out', 0, 'true'),
(59, 88, 7, '2017-11-13', 'he is perfect', 'in', 103, 'true'),
(60, 89, 13, '2017-11-12', 'NOT YET CONSULTED', 'out', 0, 'false'),
(61, 89, 13, '2017-11-13', 'bjnk', 'out', 400, 'true');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` bigint(10) UNSIGNED NOT NULL,
  `emp_name` varchar(25) NOT NULL,
  `emp_age` int(3) NOT NULL,
  `emp_sex` varchar(6) NOT NULL,
  `emp_contact` bigint(10) NOT NULL,
  `salary` int(8) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `experience` int(3) NOT NULL,
  `emp_type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `emp_name`, `emp_age`, `emp_sex`, `emp_contact`, `salary`, `qualification`, `experience`, `emp_type`) VALUES
(1, 'N.Prasad Reddy', 52, 'Male', 8790317310, 500000, 'M.D.(cardiology)', 20, 'Doctor'),
(2, 'S.Anupama', 32, 'Female', 9849568842, 30000, 'General Nursing', 3, 'Nurse'),
(3, 'K.Sunil Kumar', 47, 'Male', 8790317539, 200000, 'M.D.(Diabetician)', 15, 'Doctor'),
(4, 'L.Vijay Shekhar', 50, 'Male', 8978359921, 300000, 'M.S(pediatrician)', 22, 'Doctor'),
(5, 'L.Ravi Kumar', 50, 'Male', 9000012821, 300000, 'BHMS(pediatrician)', 22, 'Doctor'),
(6, 'K.Sangeetha', 48, 'Female', 8978318564, 100000, 'M.S (General Surgeon)', 19, 'Doctor'),
(7, 'L.Prashanthi', 47, 'Female', 9704452944, 100000, 'BHMS (Hepatology)', 19, 'Doctor'),
(8, 'P.Parthasarathi', 56, 'Male', 961453287, 200000, 'M.S (Nephrology)', 25, 'Doctor'),
(9, 'B.Surender Reddy', 54, 'Male', 784596321, 800000, 'M.S (Pulmonology)', 23, 'Doctor'),
(10, 'P.Gopi Chand', 60, 'Male', 9178521612, 1000000, 'M.S (Cardiology)', 25, 'Doctor'),
(11, 'S.Rachana', 35, 'Male', 8973208538, 50000, 'General Nursing', 7, 'Nurse'),
(12, 'K.Mamatha', 54, 'Female', 9089742365, 1000000, 'M.S (Gynecology)', 22, 'Doctor'),
(13, 'T.Srinivas Naidu', 49, 'Male', 786425319, 500000, 'M.S (Neurology)', 15, 'Doctor'),
(14, 'K.Chaitanya Naidu', 50, 'Male', 9840612373, 400000, 'M.S (Nephrology)', 18, 'Doctor'),
(15, 'D.Arjun Reddy', 53, 'Male', 9840615789, 200000, 'M.S (Neurology)', 19, 'Doctor'),
(16, 'A.Ramnath Sarma', 50, 'Male', 9782318656, 250000, 'M.S (Pulmonology)', 17, 'Doctor'),
(17, 'R.Vishwanath', 52, 'Male', 8978359785, 300000, 'M.S (Hepatology)', 21, 'Doctor'),
(18, 'M.Shruthi', 46, 'Female', 8978348862, 300000, 'M.S Gynecology)', 16, 'Doctor'),
(19, 'Y.Jagan mohan', 50, 'Male', 8978354512, 300000, 'M.S (General Surgeon)', 18, 'Doctor'),
(20, 'S.Pranathi', 47, 'Female', 8978356981, 300000, 'M.S (Psychiatry)', 14, 'Doctor'),
(21, 'D.Ravinder Reddy', 40, 'Male', 9848022338, 300000, 'M.S (Diabetics)', 20, 'Doctor'),
(22, 'V.Chakravarthi', 60, 'Male', 7896213540, 300000, 'M.S (Psychiatry)', 28, 'Doctor'),
(23, 'A.Ganesh', 40, 'Male', 8958358921, 80000, 'General Nursing', 8, 'Nurse'),
(24, 'E.Sushmitha', 34, 'Female', 8974527921, 40000, 'General Nursing', 12, 'Nurse'),
(25, 'H.Guna Sekhar', 40, 'Male', 8978359921, 30000, 'General Nursing', 12, 'Nurse'),
(26, 'T.Sushma', 33, 'Female', 978612354, 30000, 'General Nursing', 9, 'Nurse'),
(27, 'A.Alekhya', 35, 'Female', 8978359921, 90000, 'General Nursing', 8, 'Receptionist'),
(28, 'G.Preethi', 28, 'Female', 8978786645, 80000, 'General NUrsing', 3, 'Receptionist'),
(32, 'B.Sai Sameer', 32, 'Male', 8280042895, 250000, 'M.S.(Cardiology)', 5, 'Doctor'),
(34, 'V.Chakri', 32, 'Male', 8275642859, 25000, 'General Nursing', 6, 'Nurse'),
(35, 'Rama Chetan', 29, 'Male', 8500268103, 250000, 'MBBS,FRCS (London Ret.)', 5, 'Doctor'),
(36, 'V.Chakri', 28, 'Male', 9078814689, 25000, 'B.Sc', 3, 'Receptionist');

-- --------------------------------------------------------

--
-- Table structure for table `emp_doctor`
--

CREATE TABLE `emp_doctor` (
  `doc_id` bigint(10) UNSIGNED NOT NULL,
  `specialisation` varchar(20) NOT NULL,
  `consultation` int(5) NOT NULL DEFAULT '500',
  `max_patients` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_doctor`
--

INSERT INTO `emp_doctor` (`doc_id`, `specialisation`, `consultation`, `max_patients`) VALUES
(1, 'Cardiology', 500, 30),
(3, 'Diabetician', 500, 25),
(4, 'Pediatrician', 500, 25),
(5, 'Pediatrician', 500, 20),
(6, 'General Surgeon', 500, 20),
(7, 'Hepatology', 500, 20),
(8, 'Nephrology', 500, 30),
(9, 'Pulmonology', 500, 20),
(10, 'Cardiology', 500, 25),
(12, 'Gynecology', 500, 20),
(13, 'Neurology', 500, 20),
(14, 'Nephrology', 500, 25),
(15, 'Neurology', 500, 1),
(16, 'Pulmonology', 500, 25),
(17, 'Hepatology', 500, 25),
(18, 'Gynecology', 500, 25),
(19, 'General Surgeon', 500, 20),
(20, 'Psychiatrist', 500, 20),
(21, 'Diabetician', 500, 25),
(22, 'Psychiatrist', 500, 20),
(32, 'Cardiology', 500, 2),
(35, 'Neurology', 1000, 20);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `Pat_id` bigint(10) UNSIGNED NOT NULL,
  `Pat_name` varchar(20) NOT NULL,
  `Pat_age` int(3) NOT NULL,
  `Pat_sex` varchar(6) NOT NULL,
  `Pat_contact` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`Pat_id`, `Pat_name`, `Pat_age`, `Pat_sex`, `Pat_contact`) VALUES
(72, 'sam', 21, 'male', 123456),
(73, 'tarun', 20, 'male', 907881445),
(74, 'same', 20, 'mal', 98645),
(75, 'sameer krishna', 20, 'Male', 9178521612),
(76, 'sameer krishna', 20, 'Male', 917852),
(77, 'sameer krishna', 20, 'Male', 9178521612),
(78, 'sameer krishna', 20, 'Male', 9178521612),
(79, 'sameer', 20, 'Male', 9178521612),
(80, 'indra t', 19, 'm', 8280329025),
(81, 'koti', 21, 'male', 8280042896),
(82, 'Naruto', 25, 'Male', 7894561230),
(83, 'chakri', 19, 'M', 9078814698),
(84, 'codeshwar', 69, 'B', 911),
(85, 'codeshwar', 69, 'B', 911),
(86, 'thop', 21, 'male', 9966603396),
(87, 'Rama Chetan', 19, 'Male', 8500268103),
(88, 'rakesh', 21, 'male', 7893208542),
(89, 'K.Rakesh', 24, 'Male', 9603880954);

-- --------------------------------------------------------

--
-- Table structure for table `patient_admit`
--

CREATE TABLE `patient_admit` (
  `app_no` bigint(10) UNSIGNED NOT NULL,
  `room_no` int(5) NOT NULL,
  `date_admitted` date NOT NULL DEFAULT '0000-00-00',
  `date_discharged` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_admit`
--

INSERT INTO `patient_admit` (`app_no`, `room_no`, `date_admitted`, `date_discharged`) VALUES
(32, 1, '2017-11-11', '2017-11-11'),
(46, 13, '2017-11-11', '2017-11-11'),
(47, 4, '2017-11-11', '2017-11-11'),
(51, 2, '2017-11-11', '2017-11-12'),
(59, 4, '2017-11-13', '2017-11-13');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_no` int(5) NOT NULL,
  `nurse_id` bigint(10) UNSIGNED NOT NULL,
  `occupied` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_no`, `nurse_id`, `occupied`) VALUES
(1, 2, 0),
(2, 2, 0),
(3, 34, 0),
(4, 2, 0),
(5, 23, 0),
(6, 23, 0),
(7, 34, 0),
(8, 23, 0),
(9, 24, 0),
(10, 24, 0),
(11, 34, 0),
(12, 24, 0),
(13, 25, 0),
(14, 25, 0),
(15, 25, 0),
(16, 25, 0),
(17, 26, 0),
(18, 26, 0),
(19, 26, 0),
(20, 26, 0),
(21, 11, 0),
(22, 34, 0),
(23, 11, 0),
(24, 11, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`app_no`),
  ADD KEY `p_id` (`pat_id`),
  ADD KEY `d_id` (`doc_id`),
  ADD KEY `app_date` (`app_date`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `emp_doctor`
--
ALTER TABLE `emp_doctor`
  ADD UNIQUE KEY `doc_id` (`doc_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`Pat_id`);

--
-- Indexes for table `patient_admit`
--
ALTER TABLE `patient_admit`
  ADD KEY `admit_appno` (`app_no`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_no`),
  ADD KEY `nurse_id` (`nurse_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `app_no` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `Pat_id` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `emp_doctor` (`doc_id`),
  ADD CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`pat_id`) REFERENCES `patient` (`Pat_id`);

--
-- Constraints for table `emp_doctor`
--
ALTER TABLE `emp_doctor`
  ADD CONSTRAINT `emp_doctor_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `employee` (`emp_id`);

--
-- Constraints for table `patient_admit`
--
ALTER TABLE `patient_admit`
  ADD CONSTRAINT `patient_admit_ibfk_1` FOREIGN KEY (`app_no`) REFERENCES `appointment` (`app_no`);

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`nurse_id`) REFERENCES `employee` (`emp_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
